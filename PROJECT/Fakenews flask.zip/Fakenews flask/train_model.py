import pandas as pd
import nltk
import string
import pickle

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

nltk.download('stopwords')
from nltk.corpus import stopwords

# Load dataset
df = pd.read_csv("fake_news_dataset.csv")

# Clean column names
df.columns = df.columns.str.strip()

# Combine text
df['content'] = df['title'].fillna('') + " " + df['text'].fillna('')

# Clean labels
df['label'] = df['label'].astype(str).str.strip().str.upper()

# Map labels
df['label'] = df['label'].map({
    'FAKE': 0,
    'REAL': 1
})

# Remove invalid rows
df = df.dropna(subset=['label'])

# Stopwords
stop_words = set(stopwords.words('english'))

# Clean function
def clean_text(text):
    text = str(text).lower()
    text = "".join([char for char in text if char.isalnum() or char == " "])
    words = text.split()
    words = [word for word in words if word not in stop_words]
    if len(words) == 0:
        return "emptytext"
    return " ".join(words)

# Apply cleaning
df['content'] = df['content'].apply(clean_text)

# Features
vectorizer = TfidfVectorizer()
X = vectorizer.fit_transform(df['content'])
y = df['label']

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# Model
model = LogisticRegression()
model.fit(X_train, y_train)

# Accuracy
y_pred = model.predict(X_test)
print("Accuracy:", accuracy_score(y_test, y_pred))

# Save model
pickle.dump(model, open("model.pkl", "wb"))
pickle.dump(vectorizer, open("vectorizer.pkl", "wb"))

print("Model trained successfully!")