from flask import Flask, render_template, request
import pickle
import string
from nltk.corpus import stopwords

app = Flask(__name__)

# Load model
model = pickle.load(open("model.pkl", "rb"))
vectorizer = pickle.load(open("vectorizer.pkl", "rb"))

stop_words = set(stopwords.words('english'))

# Same cleaning as training
def clean_text(text):
    text = str(text).lower()
    text = "".join([char for char in text if char.isalnum() or char == " "])
    words = text.split()
    words = [word for word in words if word not in stop_words]
    if len(words) == 0:
        return "emptytext"
    return " ".join(words)

@app.route('/')
def home():
    return render_template("index.html")

@app.route('/predict', methods=['POST'])
def predict():
    news = request.form['news']

    cleaned = clean_text(news)
    data = vectorizer.transform([cleaned])

    prediction = model.predict(data)[0]

    if prediction == 1:
        result = "REAL NEWS ✅"
    else:
        result = "FAKE NEWS ❌"

    return render_template("index.html", prediction=result)

if __name__ == "__main__":
    app.run(debug=True) 